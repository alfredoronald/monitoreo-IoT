# Historico compartido: 28-29 octubre 2026

## Contenido y procedencia

- lecturas.csv: **10.418 filas** de public.lecturas, incluidos registros anteriores de pruebas.
- sesion-20261028.csv: subconjunto de **10.381 filas**, desde el 28/10 16:32 hasta el 29/10 07:40, America/La_Paz; unas **15 h 8 min** con cortes.
- resumen.json: conteos por variable, fechas y huecos mayores a 60 s. No son 24 h continuas.
- calibraciones-referencia.json y umbrales-referencia.json: referencias de procedencia, no se aplican automaticamente ni reemplazan configuracion vigente de otro sensor.
- esquema-referencia.sql: esquema versionado del proyecto, para quien aun no lo tenga instalado. Procede de feature/backend-mqtt-api.
- importar-lecturas.sql: carga transaccional e idempotente de lecturas.csv; no contiene credenciales.

El historico es mixto: contiene pruebas anteriores, lecturas previas a Ro configurado, cambios de intervalo y capturas experimentales. No etiquetar todas las filas como CO2 calibrado ni como validacion fisica aprobada. Los CSV preservan ID de origen y fechas; el importador genera nuevos IDs locales. No se reescriben timestamps para aparentar datos actuales.

## Importacion en PostgreSQL 15 o superior

1. Extraer TODO el ZIP a una carpeta y abrir una terminal en esa carpeta. Verificar manifest-sha256.json antes de importar. No versionar contrasenas.
2. Tener PostgreSQL y la BD del proyecto instalados (README e infra/postgres del repositorio). Detener temporalmente la ingesta del backend en la BD de destino. La BD existente se conserva.
3. Si no existe el esquema, aplicar esquema-referencia.sql como indica el proyecto. Requiere los roles y permisos del proyecto; este paquete no crea usuarios ni contrasenas. No volver a aplicar el esquema solo para cargar datos si ya existe.
4. Ejecutar desde la carpeta extraida, adaptando usuario, puerto y BD locales:

```bash
psql -h localhost -p 5433 -U app -d monitoreo_ambiental -W -v ON_ERROR_STOP=1 -f importar-lecturas.sql
```

En Git Bash Windows, si psql no esta en PATH:

```bash
"/c/Program Files/PostgreSQL/15/bin/psql.exe" -h localhost -p 5433 -U app -d monitoreo_ambiental -W -v ON_ERROR_STOP=1 -f importar-lecturas.sql
```

El programa pide la contrasena local; no enviarla por chat ni ponerla en Git. `\copy` lee el CSV en la computadora del cliente: no requiere permisos de archivo del servidor. No ejecutar este archivo como SQL normal desde DBeaver, porque incluye comandos de psql.

5. En una BD sin estas lecturas, filas_insertadas debe indicar 10418 y filas_del_paquete_presentes 10418. Al repetir, inserta 0 y conserva 10418 presentes. Si algunas filas ya existian, la primera cifra sera menor. La deduplicacion usa fecha, variable y valor; nunca reemplaza registros existentes.
6. Reanudar backend/API y frontend. En el historico seleccionar las fechas originales 28-29/10/2026. Las tarjetas actuales pueden mostrar "Sin datos recientes" porque la exportacion no crea lecturas nuevas. El dashboard no lee el ZIP: lee la BD importada a traves de la API.

## Detencion y reanudacion de la laptop de origen

Broker y backend de esta captura se detuvieron antes del export; PostgreSQL se detendra despues de comprobar el paquete. Desconectar el USB es lo que apaga fisicamente el ESP32: detener Mosquitto no lo desenergiza. Para otra sesion, iniciar PostgreSQL, broker, backend y conectar el ESP32; sus credenciales siguen solo en local.

No se importan automaticamente calibraciones, umbrales, alertas ni decisiones del PO: continuar con las migraciones y PR de sus areas. Este paquete comparte lecturas para explorar el historico, no sustituye la integracion del codigo.

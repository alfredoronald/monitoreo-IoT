# Seguimiento eléctrico — 28/10/2026

Mediciones comunicadas por el usuario con DT-830B en DCV 20:
- VCC del MQ: inicialmente 4,34–4,46 V; posteriormente máximo 4,56 V momentáneo.
- VIN del ESP32: inicialmente 4,54–4,56 V; luego rango aproximado 4,45–4,56 V.
- Sin serie temporal sincronizada con la captura; contacto e incertidumbre sin cuantificar.
- Conexiones declaradas: VCC→VIN, GND común, AO→10k→GPIO34→10k→GND; DO libre.

Estas observaciones cuestionan Vc=4,89 V de la configuración previa. La fotografía
no demuestra la RL interna ni la topología del módulo. No cambiar el registro
original, ni registrar el candidato original como definitivo sin revisión.

La tabla adjunta es sensibilidad matemática: reconstruye VAO desde Rs original
usando RL nominal y Vc original. Reevalúa hipotéticamente con otras alimentaciones.
NO son nuevas mediciones ni prueban el VCC presente durante el ensayo original.

| Vc hipotético (V) | Ro candidato (kOhm) |
|---:|---:|
| 4.34 | 46.839391 |
| 4.45 | 48.294975 |
| 4.50 | 48.956604 |
| 4.56 | 49.750559 |
| 4.89 | 54.117312 |

Antes de una nueva captura: confirmar VCC en el módulo, documentar variación y usar un valor de trabajo explícito con su incertidumbre; mantener identificadas RL nominal y topología supuesta. Revisar el resultado como calibración experimental, no medidor selectivo de CO2.

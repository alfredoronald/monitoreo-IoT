# Escenario Aula ventilada: captura T-8.6

Captura MQTT real de 300.02 s, sin reinicio ni cambio de Ro. Recinto aproximado y condiciones declaradas en condiciones.json.

CO2: 18 lecturas, mínimo 306.4, máximo 356.5, media 332.19 ppm. Recibidos 18 mensajes de cada variable frente a 20 teóricos; mayor hueco CO2 43.61 s. Se conservan todas las lecturas, incluidas las inferiores a 350 ppm. El requisito 350–500 aplica al escenario exterior, no constituye una regla para descartar estas lecturas.

La tarea sigue pendiente del escenario cerrado y ocupado y de comparar la tendencia. El MQ-135 y su referencia experimental conservan sus limitaciones; los valores bajos no demuestran concentracion real de CO2 inferior al exterior.

# T-8.2 / #141 — recálculo experimental con VCC de trabajo 4,54 V

Fecha: 28/10/2026. Se conservan las 60 muestras y el log originales.
Actualización solicitada por el responsable: usar 4,54 V como aproximación dentro
 del rango observado 4,45–4,56 V en VCC–GND del propio MQ-135.
NO es una captura nueva ni una tensión sincronizada con cada muestra original.

## Fórmula y unidades
RL efectiva nominal = 6666,67 ohm; topología interna supuesta, sin verificar.
VAO = 4,89 / (Rs_original / RL + 1).
Rs_recalculada = RL * (4,54 / VAO - 1).
ppm = A*(Rs/Ro)^(-B), A=116.6020682, B=2.769034857.
Ro = media(Rs_recalculada)*(420/A)^(1/B).
420 ppm es referencia aproximada asumida, no medida con equipo patrón.

## Resultado
- Muestras originales: 60, contadores 1..60 completos; 0 rechazadas.
- Media Rs recalculada: 31152.538971 ohm.
- Ro candidato recalculado: **49.485907781 kOhm**.
- CV descriptivo de Rs recalculada: 1.370080%.
- Sensibilidad para 4,45–4,56 V: Ro 48.294975–49.750559 kOhm;
  no equivale a la incertidumbre total ni a un intervalo de confianza estadístico.
- El candidato anterior 54,117312415 kOhm queda como antecedente de VCC=4,89 V,
  no como valor vigente ni aplicado al dispositivo.

## Alcance pendiente
El cambio actualiza el cálculo documental. No modifica firmware ni PostgreSQL.
El modo normal del dispositivo conserva su referencia provisional de 400 ppm.
La estabilidad, procedencia exterior y los supuestos eléctricos requieren revisión
antes de aceptar #141. No cerrar automáticamente ni presentar Ro como definitivo.

## Contenido
informe.md: este resultado actualizado.
informe-original-489.md: informe original preservado.
lecturas.csv, monitor-160656.txt, estado.json, resumen.json: originales de la captura,
 donde resumen.json conserva el resultado original con 4,89 V.
lecturas-recalculadas-454.csv y recalculo-454.json: resultados derivados, identificados.
seguimiento-electrico.md y sensibilidad-alimentacion.json: seguimiento previo.
sha256.json: integridad de cada archivo del paquete.

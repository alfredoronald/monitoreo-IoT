# Evidencia experimental T-8.2

Leer primero informe.md: cálculo documental actualizado con VCC aproximado de
4,54 V por instrucción del responsable. El dato original de 4,89 V y su resultado
se conservan como antecedentes, sin alterar los registros originales.

No se efectuó una nueva captura exterior en esta actualización. El sensor se
había trasladado al interior según comunicación del usuario. La ubicación de la
captura original se conserva como exterior según declaración del responsable.

El nuevo Ro continúa siendo candidato experimental: RL nominal, topología
supuesta y alimentación no sincronizada con cada muestra. No cierra #141 por sí
solo. Firmware, base de datos y credenciales no se modifican por esta PR.

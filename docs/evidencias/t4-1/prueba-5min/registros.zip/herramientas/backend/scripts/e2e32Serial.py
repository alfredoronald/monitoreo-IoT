"""Read the physical ESP32 without toggling reset; emit timestamped JSON lines."""
import datetime
import json
import sys

import serial


def main():
    connection = serial.Serial()
    connection.port = sys.argv[1]
    connection.baudrate = 115200
    connection.timeout = 0.5
    connection.dtr = False
    connection.rts = False
    try:
        connection.open()
        connection.reset_input_buffer()
        print(json.dumps({"event": "ready", "port": connection.port}), flush=True)
        while True:
            raw = connection.readline()
            if raw:
                print(json.dumps({
                    "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    "line": raw.decode("utf-8", errors="replace").rstrip(),
                }, ensure_ascii=False), flush=True)
    finally:
        connection.close()


if __name__ == "__main__":
    main()

# T-8.2 / #141 — captura física experimental del 28/10/2026

Estado: captura completa; pendiente validación de supuestos y aceptación.
No es una certificación metrológica de CO2.

## Condiciones registradas
- Lugar: exterior según declaración del usuario; no verificado remotamente.
- Acondicionamiento: mínimo de 15 minutos según issue actualizada. La captura
  comenzó después de 900000 ms del arranque; esto no acredita un ensayo de 24 h.
- Fuente: ADC físico del MQ-135. Modo EXPERIMENTAL, RL nominal no medida,
  topología supuesta según documentación de #140. No ocultar estas limitaciones.
- Registro completo: monitor-160656.txt. Tabla extraída: lecturas.csv.
- Inicio/fin y estado: estado.json. Resumen calculado: resumen.json.

## Resultado descriptivo
- Muestras: 60; contadores 1..60 completos, sin rechazadas.
- Media Rs estimada: 34068.1168 ohm.
- Mínimo/máximo: 33089.4474 / 34809.1777 ohm.
- Coeficiente de variación muestral: 1.3494%.
- Media primeras/últimas 20: 33977.0689 /
  34204.8611 ohm.
- No existe un umbral numérico acordado en la issue para aceptar estabilidad;
  estas estadísticas la describen y no sustituyen la revisión de la tendencia.

## Cálculo condicionado
Si #143 usa ppm = A*(Rs/Ro)^(-B), con A=116.6020682, B=2.769034857,
la inversa es Ro = media(Rs)*(420/A)^(1/B).
Referencia 420 ppm aproximada/asumida, no medida con equipo patrón.
Ro candidato: 54.117312415 kOhm.
La conversión actual sigue normalizada a una referencia provisional de 400 ppm;
no afirmar que este candidato ya está aplicado al firmware o registrado en BD.

## Entrega
Adjuntar tabla, log y cálculo en un comentario de #141; no requiere PR.
Revisar procedencia/estabilidad/supuestos y resolver observaciones antes de cerrar.
No sustituir el archivo original por una captura de pantalla; una captura puede
acompañarlo como evidencia visual. La PR de #142 es una tarea distinta.

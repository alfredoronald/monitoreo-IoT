"""Render clearly labelled PNG reports from the recorded integration data."""
import json
import pathlib
import sys

from PIL import Image, ImageDraw, ImageFont


def render(source, destination):
    report = json.loads(pathlib.Path(source).read_text(encoding="utf-8"))
    font_path = "C:/Windows/Fonts/segoeui.ttf"
    font = ImageFont.truetype(font_path, 25)
    title_font = ImageFont.truetype(font_path, 42)
    small = ImageFont.truetype(font_path, 21)
    rows = report["comparison"]
    lines = [
        f"Etapa: {report['stage']}  |  Tiempo observado: {report['elapsedSeconds']:.1f} s",
        f"Inicio UTC: {report['start']}  |  Captura UTC: {report['timestamp']}",
        f"Commit probado: {report['commit']}  |  ESP32 físico: {report['serialPort']} / 115200 baudios",
        f"Base: {report['database']}  |  Corte inicial ID: {report['baselineId']}",
        "",
        "Variable          ESP32 enviados     Broker MQTT     Backend recibidos     BD guardadas",
    ]
    for row in rows:
        lines.append(
            f"{row['variable']:<20} {row['published']:>8}"
            f" {row['mqtt']:>18} {row['backend']:>20} {row['saved']:>20}"
        )
    lines += [
        "",
        f"Total MQTT: {sum(r['mqtt'] for r in rows)}  |  Total BD: {sum(r['saved'] for r in rows)}",
        f"Diferencia MQTT − BD: {sum(r['mqtt'] - r['saved'] for r in rows)}",
        f"Verificación de valores: {report['valuesResult']}",
        f"Eventos / errores registrados: {len(report['incidents'])}",
        "",
        "Últimas publicaciones ESP32 observadas:",
    ]
    lines += [f"  {item['line']}" for item in report['lastPublications'][-3:]]
    lines += ["", "Últimos mensajes MQTT observados:"]
    lines += [f"  {item['timestamp']}  {item['topic']} = {item['content']}" for item in report['lastMqtt'][-3:]]
    lines += ["", "Últimas filas PostgreSQL del intervalo:"]
    lines += [f"  ID {item['id']}  {item['fecha_hora']}  {item['tipo_variable']} = {item['valor']}" for item in report['lastRows'][-3:]]
    if report['incidents']:
        lines += ["", "Eventos registrados (ver el detalle completo en los registros):"]
        lines += [f"  {item['timestamp']}  {item['kind']}: {item['detail']}" for item in report['incidents'][-4:]]
    height = max(1200, 210 + len(lines) * 37)
    image = Image.new("RGB", (1900, height), "#f5f7fb")
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 1900, 110), fill="#16324f")
    draw.text((45, 24), "T-4.1 / #32 — Integración ESP32 → PostgreSQL", font=title_font, fill="white")
    draw.text((45, 125), "REPORTE PNG GENERADO A PARTIR DE REGISTROS REALES — NO ES UNA CAPTURA DE PANTALLA", font=small, fill="#526477")
    y = 170
    for line in lines:
        draw.text((45, y), line, font=font, fill="#17324c")
        y += 37
    image.save(destination, optimize=True)


if __name__ == "__main__":
    render(sys.argv[1], sys.argv[2])

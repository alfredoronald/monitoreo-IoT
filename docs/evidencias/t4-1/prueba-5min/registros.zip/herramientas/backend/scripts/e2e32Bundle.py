"""Independently verify raw evidence, scan local secrets and create a ZIP bundle."""
import collections
import datetime
import hashlib
import json
import pathlib
import re
import sys
import zipfile

from PIL import Image


def main():
    root = pathlib.Path(__file__).resolve().parents[2]
    run = root / "docs/evidencias/t4-1/prueba-5min"
    result = json.loads((run / "final.json").read_text(encoding="utf-8"))
    start = datetime.datetime.fromisoformat(result["start"])
    end = datetime.datetime.fromisoformat(result["end"])

    def records(name):
        path = run / "registros" / name
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]

    def inside(item):
        return start <= datetime.datetime.fromisoformat(item["timestamp"]) < end

    serial = [item for item in records("esp32.jsonl") if inside(item)]
    broker = [item for item in records("mqtt.jsonl") if inside(item) and not item.get("retained")]
    backend = [item for item in records("backend.jsonl") if inside(item) and item["event"] == "received"]
    rows = json.loads((run / "registros/filas-postgresql.json").read_text(encoding="utf-8"))
    for variable in ("temperatura", "humedad", "co2"):
        pattern = re.compile(r"MQTT publicacion: ambiente/" + variable + r"; payload=([^;]+); enviado")
        published = [f"{float(match.group(1)):.2f}" for item in serial if (match := pattern.search(item["line"]))]
        mqtt_values = [f"{float(item['content']):.2f}" for item in broker if item["topic"] == "ambiente/" + variable]
        backend_values = [f"{float(item['content']):.2f}" for item in backend if item["topic"] == "ambiente/" + variable]
        stored = [f"{float(item['valor']):.2f}" for item in rows if item["tipo_variable"] == variable]
        assert len(published) == len(mqtt_values) == len(backend_values) == len(stored) == 20, variable
        assert collections.Counter(published) == collections.Counter(mqtt_values) == collections.Counter(backend_values) == collections.Counter(stored), variable
        assert mqtt_values == stored, variable
        print(f"Auditoría independiente: {variable}: 20 / 20 / 20 / 20; valores y secuencia coinciden")
    assert (end - start).total_seconds() >= 300
    assert result["incidents"] == []
    health = records("salud.jsonl")
    assert len(health) >= 10
    assert all(item["apiStatus"] == 200 and item["mqttConnected"] and item["serialRunning"] for item in health)
    assert all(item["processes"] == result["processBaseline"] for item in health)

    files = [(path, path.relative_to(run).as_posix()) for path in (run / "registros").iterdir() if path.is_file()]
    files += [(run / name, name) for name in ("inicio.json", "intermedio.json", "final.json")]
    files += [(pathlib.Path(__file__).parent / name, "herramientas/backend/scripts/" + name) for name in
              ("endToEnd32.ts", "e2e32Serial.py", "e2e32Render.py", "e2e32Bundle.py")]
    secrets = []
    config = (root / "firmware/include/config.h").read_text(encoding="utf-8")
    secrets += re.findall(r'(?:wifi_password|mqtt_password)\[\]\s*=\s*"([^"]+)"', config)
    for line in (root / "backend/.env").read_text(encoding="utf-8").splitlines():
        if "=" in line:
            name, value = line.split("=", 1)
            if re.search(r"PASS(?:WORD)?$|SECRET$|TOKEN$|API_KEY$", name.strip(), re.I):
                secrets.append(value.strip().strip("\"'"))
    assert all(not any(secret and secret in path.read_text(encoding="utf-8") for secret in secrets) for path, _ in files), "Se detectó un secreto: no generar el ZIP"
    manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for path, name in files}
    archive = run / "registros.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path, name in files:
            bundle.write(path, name)
        bundle.writestr("sha256.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
    for path in run.glob("*.png"):
        with Image.open(path) as image:
            image.verify()
    print(f"ZIP verificado: {archive.name}, {archive.stat().st_size} bytes; PNG válidos; sin secretos detectados")


if __name__ == "__main__":
    main()

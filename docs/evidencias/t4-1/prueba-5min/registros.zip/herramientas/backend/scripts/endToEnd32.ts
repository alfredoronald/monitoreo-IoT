import { spawn, execFileSync } from 'node:child_process';
import { appendFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';
import { performance } from 'node:perf_hooks';
import { setTimeout as delay } from 'node:timers/promises';
import mqtt from 'mqtt';
import { pool, connectDatabase } from '../src/db.js';
import { defaultMessageLogPath, redactLogText } from '../src/mqtt/messageLogger.js';
import { validateMessage, type ReadingVariable } from '../src/mqtt/messageValidator.js';

// Physical ESP32 is the only publisher. This script observes; it never inserts or publishes.
const root = fileURLToPath(new URL('../../', import.meta.url));
const python = process.env.E2E_PYTHON;
const serialPort = process.env.E2E_SERIAL_PORT ?? 'COM5';
const duration = Number(process.env.E2E_DURATION_SECONDS ?? 300);
const destination = join(root, 'docs/evidencias/t4-1', process.env.E2E_RUN_NAME ?? 'prueba-5min');
const variables: ReadingVariable[] = ['temperatura', 'humedad', 'co2'];
type Message = { timestamp: string; topic: string; content: string; retained?: boolean };
type SerialEntry = { timestamp: string; line: string };
type Incident = { timestamp: string; kind: string; detail: string };
type Row = { id: string; fecha_hora: Date; tipo_variable: ReadingVariable; valor: string };

if (!python) throw new Error('Define E2E_PYTHON con un Python que tenga pyserial y Pillow.');
if (!Number.isFinite(duration) || duration < 1) throw new Error('Duración inválida.');
mkdirSync(join(destination, 'registros'), { recursive: true });
const records = join(destination, 'registros');
const commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const firmwareHash = execFileSync('git', ['hash-object', 'firmware/src/main.cpp'], { cwd: root, encoding: 'utf8' }).trim();
const published: Message[] = [];
const received: Message[] = [];
const backend: Message[] = [];
const serialEntries: SerialEntry[] = [];
const incidents: Incident[] = [];
let start = '';
let end = '';
let baselineId = '0';
let capturing = false;
let lastUptime: number | undefined;
let logOffset = existsSync(defaultMessageLogPath) ? statSync(defaultMessageLogPath).size : 0;
let logPartial = '';
let serialError = '';
let processBaseline: unknown;
let databaseStarted = '';
let firstRows: Row[] = [];
let startedAt = 0;

function saveJson(path: string, value: unknown) {
  writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
}
function incident(kind: string, detail: string) {
  const item = { timestamp: new Date().toISOString(), kind, detail: redactLogText(detail) };
  incidents.push(item);
  appendFileSync(join(records, 'eventos.jsonl'), JSON.stringify(item) + '\n');
  console.log(`[EVENTO] ${kind}: ${item.detail}`);
}
function inWindow(timestamp: string) {
  return Boolean(start) && timestamp >= start && (!end || timestamp < end);
}
function serialLine(entry: SerialEntry) {
  entry.line = redactLogText(entry.line);
  appendFileSync(join(records, 'esp32.jsonl'), JSON.stringify(entry) + '\n');
  if (!capturing || !inWindow(entry.timestamp)) return;
  serialEntries.push(entry);
  const uptime = /^\[(\d+) ms\]/.exec(entry.line);
  if (uptime) {
    const current = Number(uptime[1]);
    if (lastUptime !== undefined && current + 1000 < lastUptime) incident('reinicio-esp32', entry.line);
    lastUptime = current;
  }
  if (/Firmware ESP32 iniciado|rst:0x|Guru Meditation|Brownout/.test(entry.line)) incident('reinicio-esp32', entry.line);
  if (/MQTT: desconectado|MQTT: intento fallido|WiFi: desconectado|WiFi: intento sin asociaci/.test(entry.line)) incident('conexion-esp32', entry.line);
  if (/DHT22 ERROR|DHT22 DESCARTADA|MQTT omitido|fallo; sin reenvio/.test(entry.line)) incident('lectura-o-publicacion', entry.line);
  const message = /MQTT publicacion: (ambiente\/\w+); payload=([^;]+); enviado/.exec(entry.line);
  if (message) published.push({ timestamp: entry.timestamp, topic: message[1], content: message[2] });
}

const serial = spawn(python, ['-u', fileURLToPath(new URL('./e2e32Serial.py', import.meta.url)), serialPort], { stdio: ['ignore', 'pipe', 'pipe'] });
serial.stderr.on('data', (chunk: Buffer) => { serialError += chunk.toString(); });
const serialReady = new Promise<void>((resolve, reject) => {
  const timeout = setTimeout(() => reject(new Error('No se pudo abrir el puerto serial: ' + serialError)), 8000);
  const lines = createInterface({ input: serial.stdout });
  lines.on('line', line => {
    try {
      const value = JSON.parse(line);
      if (value.event === 'ready') { clearTimeout(timeout); resolve(); }
      else if (value.line !== undefined) serialLine(value);
    } catch { if (capturing) incident('serial-formato', 'Línea JSON no válida del observador serial'); }
  });
  serial.on('error', error => { clearTimeout(timeout); reject(error); });
  serial.on('exit', code => { if (capturing) incident('observador-serial', `Proceso terminó: ${code}; ${serialError}`); });
});

const observer = mqtt.connect(process.env.MQTT_URL!, {
  username: process.env.MQTT_USER,
  password: process.env.MQTT_PASS,
  clientId: `e2e32-observador-${Date.now()}`,
  clean: true,
  reconnectPeriod: 2000,
  connectTimeout: 5000,
});
const observerReady = new Promise<void>((resolve, reject) => {
  const timeout = setTimeout(() => reject(new Error('El observador no logró suscribirse a MQTT')), 10000);
  observer.on('connect', () => observer.subscribe('ambiente/#', { qos: 0 }, (error, granted) => {
    if (error || !granted?.length || granted.some(item => item.qos === 128)) {
      clearTimeout(timeout); reject(error ?? new Error('Suscripción MQTT rechazada')); return;
    }
    clearTimeout(timeout); resolve();
  }));
});
observer.on('error', error => { if (capturing) incident('observador-mqtt', error.message); });
observer.on('offline', () => { if (capturing) incident('observador-mqtt', 'Conexión al broker interrumpida'); });
observer.on('message', (topic, payload, packet) => {
  const item = { timestamp: new Date().toISOString(), topic, content: redactLogText(payload.toString()), retained: packet.retain };
  appendFileSync(join(records, 'mqtt.jsonl'), JSON.stringify(item) + '\n');
  if (capturing && inWindow(item.timestamp) && !item.retained && validateMessage(topic, item.content).valid) received.push(item);
});

function captureBackend() {
  if (!existsSync(defaultMessageLogPath)) return;
  const buffer = readFileSync(defaultMessageLogPath);
  if (buffer.length < logOffset) { incident('log-backend', 'El log fue truncado durante la prueba'); logOffset = 0; }
  logPartial += buffer.subarray(logOffset).toString('utf8');
  logOffset = buffer.length;
  const lines = logPartial.split('\n');
  logPartial = lines.pop() ?? '';
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const item = JSON.parse(line);
      appendFileSync(join(records, 'backend.jsonl'), JSON.stringify(item) + '\n');
      if (!inWindow(item.timestamp)) continue;
      if (item.event === 'received' && validateMessage(item.topic, item.content).valid) backend.push(item);
      if (item.event === 'discarded' && item.topic !== 'ambiente/status') incident('backend-descartado', `${item.topic}: ${item.reason}`);
    } catch { incident('log-backend', 'Entrada JSON no válida'); }
  }
}

function processes() {
  const output = execFileSync('pwsh', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command',
    '$items = @(Get-NetTCPConnection -State Listen -LocalPort 1883,3000,5432 -ErrorAction SilentlyContinue | ForEach-Object { $p = Get-Process -Id $_.OwningProcess; $started = $null; if ($null -ne $p.StartTime) { $started = $p.StartTime.ToUniversalTime().ToString("o") }; [pscustomobject]@{ port=$_.LocalPort; pid=$_.OwningProcess; started=$started } }); ConvertTo-Json -InputObject $items -Compress'],
  { encoding: 'utf8', timeout: 10000 });
  const items = JSON.parse(output) as { port: number; pid: number; started: string }[];
  return [1883, 3000, 5432].map(port => {
    const match = items.find(item => item.port === port);
    return match ?? { port, pid: null, started: null };
  });
}

async function rows(): Promise<Row[]> {
  return (await pool.query('SELECT id, fecha_hora, tipo_variable, valor FROM lecturas WHERE id > $1 AND fecha_hora >= $2 AND fecha_hora < $3 ORDER BY id',
    [baselineId, start, end || new Date().toISOString()])).rows;
}
function values(messages: Message[], variable: ReadingVariable) {
  return messages.filter(item => item.topic === `ambiente/${variable}`).map(item => Number(item.content).toFixed(2));
}
function bagDiff(expected: string[], actual: string[]) {
  const bag = new Map<string, number>();
  for (const item of expected) bag.set(item, (bag.get(item) ?? 0) + 1);
  for (const item of actual) bag.set(item, (bag.get(item) ?? 0) - 1);
  return [...bag].filter(([, count]) => count !== 0).map(([value, count]) => ({ value, count }));
}
async function snapshot(stage: string, elapsedSeconds: number, final = false) {
  captureBackend();
  const saved = await rows();
  const comparison = variables.map(variable => {
    const source = values(published, variable);
    const broker = values(received, variable);
    const consumer = values(backend, variable);
    const stored = saved.filter(row => row.tipo_variable === variable).map(row => Number(row.valor).toFixed(2));
    return { variable, published: source.length, mqtt: broker.length, backend: consumer.length, saved: stored.length,
      publishedVsMqtt: bagDiff(source, broker), mqttVsBackend: bagDiff(broker, consumer), mqttVsDatabase: bagDiff(broker, stored),
      sequenceMatches: JSON.stringify(broker) === JSON.stringify(stored) };
  });
  const allMatch = comparison.every(item => !item.publishedVsMqtt.length && !item.mqttVsBackend.length && !item.mqttVsDatabase.length && item.sequenceMatches);
  const result = {
    stage, timestamp: new Date().toISOString(), start, end: end || null, elapsedSeconds, commit, firmwareHash,
    database: process.env.PG_DB, serialPort, baselineId, processBaseline, databaseStarted,
    comparison, incidents, allMatch, reducedTest: true, original30MinuteCriterionMet: duration >= 1800,
    valuesResult: allMatch ? 'Cantidades, valores y secuencias coinciden en las cuatro etapas.' : (final ? 'Hay diferencias; consultar comparación y registros.' : 'Comparación provisional; puede haber guardados en curso.'),
    lastPublications: serialEntries.filter(item => /MQTT publicacion:/.test(item.line)).slice(-3),
    lastMqtt: received.slice(-3), lastRows: saved.slice(-3),
    stabilityPass: final && elapsedSeconds >= duration && incidents.length === 0,
    dataPass: final && allMatch && comparison.every(item => item.saved > 0),
  };
  saveJson(join(destination, `${stage}.json`), result);
  execFileSync(python!, [fileURLToPath(new URL('./e2e32Render.py', import.meta.url)), join(destination, `${stage}.json`), join(destination, `${stage}.png`)], { timeout: 15000 });
  if (final) {
    saveJson(join(records, 'filas-postgresql.json'), saved);
    writeFileSync(join(records, 'filas-postgresql.csv'), 'id,fecha_hora,tipo_variable,valor\n' + saved.map(row => `${row.id},${row.fecha_hora.toISOString()},${row.tipo_variable},${row.valor}`).join('\n') + '\n');
    const table = ['| Variable | ESP32 enviados | MQTT recibidos | Backend recibidos | BD guardadas | MQTT − BD |', '|---|---:|---:|---:|---:|---:|',
      ...comparison.map(item => `| ${item.variable} | ${item.published} | ${item.mqtt} | ${item.backend} | ${item.saved} | ${item.mqtt - item.saved} |`)];
    const report = [
      '# T-4.1 / #32 — Prueba reducida de integración de extremo a extremo', '',
      'Duración reducida a 5 minutos por indicación del usuario. No acredita el criterio original de 30 minutos; la descripción de #32 debe actualizarse.', '',
      `- Commit probado: \`${commit}\`; hash de firmware/src/main.cpp: \`${firmwareHash}\`.`,
      '- Dispositivo físico: ESP32-D0WD-V3, MAC 24:dc:c3:98:90:4c, COM5 / 115200 baudios.',
      `- Inicio UTC: ${start}.`, `- Fin de la ventana UTC: ${end}.`,
      `- Duración de la ventana: ${elapsedSeconds.toFixed(3)} segundos; objetivo: ${duration} segundos.`,
      `- Base: ${process.env.PG_DB}; ID inicial: ${baselineId}.`,
      '- Un solo ESP32 publica. La herramienta observa: no publica mensajes sintéticos ni inserta filas.',
      '- Los PNG son reportes generados desde datos reales, identificados como tales; los JSONL/CSV conservan los registros.', '',
      '## Comparación', '', ...table, '',
      '## Método y límites', '',
      '- Se cuentan únicamente temperatura, humedad y co2; se excluyen status y mensajes retained.',
      '- Ventana delimitada por tiempo y corte inicial de ID; se conservan mensajes anteriores/posteriores como guardas en los registros.',
      '- Tras cerrar la ventana se esperan 5 segundos para los guardados pendientes.',
      '- Se comparan cantidades y multiconjuntos de valores (incluyendo repeticiones) entre ESP32, broker, backend y BD; además, secuencias MQTT/BD por variable.',
      '- Payload físico: un decimal; BD NUMERIC(8,2). Se normaliza a dos decimales.',
      '- El contrato no tiene identificador de mensaje. No se atribuyen correspondencias únicas a valores repetidos ni se usa un conteo teórico.',
      '- Salud: API, PostgreSQL y PIDs/fechas de inicio de broker/backend/BD, más monitor serial y conexión del observador MQTT.', '',
      '## Resultado', '', `- Comparación final: ${result.valuesResult}`,
      `- Estabilidad estricta (sin eventos registrados, ventana de ${duration} s): ${result.stabilityPass ? 'CUMPLE' : 'NO ACREDITADA'}.`,
      `- Cantidades y valores con datos para las tres variables: ${result.dataPass ? 'CUMPLE' : 'NO CUMPLE'}.`,
      `- Eventos registrados: ${incidents.length}.`,
      ...incidents.map(item => `  - ${item.timestamp} — ${item.kind}: ${item.detail}`), '',
      '## Evidencias', '', '- [Inicio](inicio.png)', '- [Punto intermedio](intermedio.png)', '- [Final](final.png)',
      '- [Comparación detallada](final.json)', '- [Registros](registros/)', '',
      'La prueba no se declara aprobada cuando existen diferencias o eventos que comprometen la continuidad.', '',
    ].join('\n');
    writeFileSync(join(destination, 'informe.md'), report);
  }
  console.log(`[${stage}] ${elapsedSeconds.toFixed(1)} s; MQTT=${received.length}; BD=${saved.length}; eventos=${incidents.length}`);
  return result;
}

async function health() {
  const timestamp = new Date().toISOString();
  try {
    const response = await fetch(`http://localhost:${process.env.API_PORT ?? 3000}/`, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error(`API HTTP ${response.status}`);
    const database = await pool.query('SELECT now() AS server_time, pg_postmaster_start_time() AS started, COUNT(*) AS count FROM lecturas');
    if (database.rows[0].started.toISOString() !== databaseStarted) incident('postgresql-reinicio', 'Cambió pg_postmaster_start_time()');
    const current = processes();
    if (JSON.stringify(current) !== JSON.stringify(processBaseline)) incident('procesos', 'Cambió o desapareció un proceso de broker/backend/BD');
    appendFileSync(join(records, 'salud.jsonl'), JSON.stringify({ timestamp, apiStatus: response.status, database: database.rows[0], processes: current, mqttConnected: observer.connected, serialRunning: serial.exitCode === null }) + '\n');
    if (!observer.connected) incident('observador-mqtt', 'Sin conexión en sondeo de salud');
    if (serial.exitCode !== null) incident('observador-serial', 'Sin proceso serial en sondeo de salud');
  } catch (error) { incident('salud', error instanceof Error ? error.message : String(error)); }
  captureBackend();
}

try {
  await Promise.all([serialReady, observerReady, connectDatabase()]);
  processBaseline = processes();
  if ((processBaseline as { pid: number | null }[]).some(item => item.pid === null)) throw new Error('Falta un proceso de broker/backend/PostgreSQL');
  const baseline = await pool.query('SELECT COALESCE(MAX(id),0) AS id, pg_postmaster_start_time() AS started FROM lecturas');
  baselineId = baseline.rows[0].id;
  databaseStarted = baseline.rows[0].started.toISOString();
  firstRows = (await pool.query('SELECT id,fecha_hora,tipo_variable,valor FROM lecturas ORDER BY id DESC LIMIT 6')).rows;
  saveJson(join(records, 'previas-postgresql.json'), firstRows);
  logOffset = existsSync(defaultMessageLogPath) ? statSync(defaultMessageLogPath).size : 0;
  start = new Date().toISOString();
  startedAt = performance.now();
  capturing = true;
  let initialTaken = false;
  let middleTaken = false;
  let nextHealth = 0;
  while ((performance.now() - startedAt) / 1000 < duration) {
    const elapsed = (performance.now() - startedAt) / 1000;
    if (elapsed >= nextHealth) {
      await health();
      console.log(`[PROGRESO] ${elapsed.toFixed(1)}/${duration} s; publicados=${published.length}; mqtt=${received.length}; backend=${backend.length}; eventos=${incidents.length}`);
      nextHealth += 30;
    }
    if (!initialTaken && elapsed >= Math.min(20, duration / 3)) {
      await snapshot('inicio', elapsed);
      initialTaken = true;
    }
    if (!middleTaken && elapsed >= duration / 2) { await snapshot('intermedio', elapsed); middleTaken = true; }
    await delay(200);
  }
  const elapsed = (performance.now() - startedAt) / 1000;
  end = new Date().toISOString();
  capturing = false;
  await delay(5000);
  await health();
  const result = await snapshot('final', elapsed, true);
  execFileSync(python!, [fileURLToPath(new URL('./e2e32Render.py', import.meta.url)), join(destination, 'final.json'), join(destination, 'comparacion.png')], { timeout: 15000 });
  if (!result.stabilityPass || !result.dataPass) process.exitCode = 2;
} catch (error) {
  incident('ejecucion', error instanceof Error ? error.message : String(error));
  saveJson(join(destination, 'fallo-ejecucion.json'), { start, end, incidents });
  process.exitCode = 1;
} finally {
  capturing = false;
  serial.kill();
  observer.end(true);
  await pool.end();
}

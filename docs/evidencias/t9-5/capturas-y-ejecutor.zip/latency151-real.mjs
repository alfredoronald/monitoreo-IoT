import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {readFile,writeFile,mkdir,mkdtemp,rm} from 'node:fs/promises';
import {spawn,execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomBytes} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import assert from 'node:assert/strict';
const root='C:/Users/win/Develop/monitoreo-IoT';
const runtime='C:/Users/win/AppData/Local/Temp/opencode/sprint3-runtime';
const output='C:/Users/win/AppData/Local/Temp/opencode/sprint3-pending/issue151/docs/evidencias/t9-5';
const require=createRequire(root+'/backend/package.json');
const {Pool}=require('pg'); const mqtt=require('mqtt');
const {chromium}=createRequire('C:/Users/win/AppData/Local/Temp/opencode/alerts92-browser/package.json')('playwright');
require('dotenv').config({path:root+'/backend/.env'});
const configuration={host:process.env.PG_HOST,port:Number(process.env.PG_PORT),database:process.env.PG_DB,user:process.env.PG_USER,password:process.env.PG_PASS};
const admin=new Pool(configuration);
const schema='latency151_'+randomBytes(6).toString('hex');
const key=randomBytes(24).toString('hex'),password=randomBytes(24).toString('hex');
const result={issue:151,source:'Publicaciones sintéticas aisladas; navegador Edge, API autenticada, MQTT y PostgreSQL reales',
 started:new Date().toISOString(),ended:'',measurements:[],averageSeconds:null,passed:false,cleaned:false,
 versions:{backend:'ab382e3',frontend:'9de8ba3',node:process.version},
 method:'Date.now antes de publish; detección del valor DOM seguida de requestAnimationFrame. Sin recarga, sin mocks, polling normal de 15 s.',
 apiRequests:[],apiAuthentication:{},pageErrors:[],cleanup:{schemaDropped:false,realReadingsBefore:null,realReadingsAfter:null},errors:[]};
let broker,vite,browser,publisher,subscriber,pool,server,directory,created=false;
const execute=promisify(execFile);
try {
 await mkdir(output,{recursive:true});
 result.cleanup.realReadingsBefore=Number((await admin.query('SELECT count(*) FROM public.lecturas')).rows[0].count);
 await admin.query(`CREATE SCHEMA ${schema}`);created=true;
 process.env.PGOPTIONS='-c search_path='+schema;
 process.env.API_KEY=key;process.env.MQTT_PASS=password;process.env.MQTT_USER='backend';
 process.env.MQTT_URL='mqtt://127.0.0.1:18848';
 const db=await import(pathToFileURL(runtime+'/backend/backend/src/db.ts'));
 pool=db.pool;
 await pool.query(await readFile(root+'/database/esquema.sql','utf8'));
 directory=await mkdtemp('C:/Users/win/AppData/Local/Temp/opencode/latency151-');
 const passwd=directory+'/passwd';
 await execute('C:/Program Files/mosquitto/mosquitto_passwd.exe',['-b','-c',passwd,'backend',password]);
 await execute('C:/Program Files/mosquitto/mosquitto_passwd.exe',['-b',passwd,'esp32',password]);
 await writeFile(directory+'/mosquitto.conf',`listener 18848 127.0.0.1\nallow_anonymous false\npassword_file ${passwd}\nacl_file ${root}/infra/mosquitto/acl\npersistence false\n`);
 broker=spawn('C:/Program Files/mosquitto/mosquitto.exe',['-c',directory+'/mosquitto.conf'],{stdio:'ignore'});
 await delay(500);
 if(broker.exitCode!==null)throw Error('No arrancó broker aislado');
 const {startMqttSubscriber}=await import(pathToFileURL(runtime+'/backend/backend/src/mqtt/mqttSubscriber.ts'));
 subscriber=startMqttSubscriber(undefined,()=>{});
 await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(Error('Sin SUBACK')),10000);
  subscriber.on('packetreceive',packet=>{if(packet.cmd==='suback'){clearTimeout(timer);resolve()}});
  subscriber.once('error',reject);
 });
 const {createApp}=await import(pathToFileURL(runtime+'/backend/backend/src/app.ts'));
 server=createApp('http://localhost:5195',key).listen(3095,'127.0.0.1');
 const api='http://localhost:3095/api/lecturas/ultima';
 result.apiAuthentication.withoutKey=(await fetch(api)).status;
 result.apiAuthentication.wrongKey=(await fetch(api,{headers:{'X-API-Key':'incorrecta'}})).status;
 result.apiAuthentication.correctKey=(await fetch(api,{headers:{'X-API-Key':key}})).status;
 assert.deepEqual(result.apiAuthentication,{withoutKey:401,wrongKey:401,correctKey:200});
 vite=spawn(process.execPath,[root+'/frontend/node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5195','--strictPort'],
 {cwd:runtime+'/frontend/frontend',env:{...process.env,VITE_API_URL:'http://localhost:3095/api',VITE_API_KEY:key},stdio:'ignore'});
 for(let i=0;i<100;i++){
  try{if((await fetch('http://localhost:5195')).ok)break;}catch{}
  if(i===99)throw Error('No arrancó frontend');await delay(100);
 }
 publisher=await mqtt.connectAsync(process.env.MQTT_URL,{username:'esp32',password,reconnectPeriod:0});
 browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1366,height:900}});
 page.on('pageerror',e=>result.pageErrors.push(e.message));
 page.on('request',request=>{
  if(request.url().startsWith('http://localhost:3095/api/'))result.apiRequests.push({timestamp:new Date().toISOString(),path:new URL(request.url()).pathname,keyPresent:request.headers()['x-api-key']===key});
 });
 await page.goto('http://localhost:5195');
 await page.waitForSelector('.metric-card.temperature');
 for(let i=0;i<10;i++){
  const value=901+i;
  const start=Date.now();
  await publisher.publishAsync('ambiente/temperatura',String(value),{qos:0,retain:false});
  await page.waitForFunction(expected=>document.querySelector('.metric-card.temperature .metric-value span:first-child')?.textContent===String(expected),value,{timeout:25000,polling:'raf'});
  const displayed=await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(Date.now())))));
  const row=(await pool.query("SELECT id::text,valor FROM lecturas WHERE tipo_variable='temperatura' AND valor=$1 ORDER BY id LIMIT 1",[value])).rows[0];
  assert.ok(row);
  result.measurements.push({value,published:new Date(start).toISOString(),displayed:new Date(displayed).toISOString(),seconds:(displayed-start)/1000,readingId:row.id});
  if(i===0||i===9)await page.screenshot({path:output+`/captura-medida-${i+1}.png`,fullPage:true});
  console.log(`Medición ${i+1}: ${(displayed-start)/1000}s`);
  await delay(100);
 }
 result.averageSeconds=result.measurements.reduce((sum,m)=>sum+m.seconds,0)/10;
 assert.equal(result.apiRequests.every(request=>request.keyPresent),true);
 assert.equal(result.pageErrors.length,0);
 result.passed=result.averageSeconds<20;
}catch(e){result.errors.push(e.message);process.exitCode=1;}
finally{
 if(browser)await browser.close();
 for(const client of [publisher,subscriber])if(client)await client.endAsync(true);
 if(server)await new Promise(resolve=>server.close(resolve));
 if(pool)await pool.end();
 for(const child of [vite,broker])if(child&&child.exitCode===null){await new Promise(resolve=>{child.once('exit',resolve);child.kill()});}
 if(created){await admin.query(`DROP SCHEMA ${schema} CASCADE`);result.cleanup.schemaDropped=(await admin.query('SELECT 1 FROM pg_namespace WHERE nspname=$1',[schema])).rowCount===0;}
 result.cleanup.realReadingsAfter=Number((await admin.query('SELECT count(*) FROM public.lecturas')).rows[0].count);
 result.cleaned=result.cleanup.schemaDropped&&result.cleanup.realReadingsBefore===result.cleanup.realReadingsAfter;
 if(directory)await rm(directory,{recursive:true,force:true});
 await admin.end();result.ended=new Date().toISOString();
 result.passed&&=result.cleaned&&result.errors.length===0;
 await writeFile(output+'/latencia-real.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({passed:result.passed,average:result.averageSeconds,measurements:result.measurements.length,cleaned:result.cleaned,errors:result.errors}));
}

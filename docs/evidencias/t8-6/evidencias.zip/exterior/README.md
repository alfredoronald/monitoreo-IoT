# Escenario Exterior: primera captura T-8.6

Captura MQTT real de 300.01 s, sin reinicio ni cambio de Ro. Posición declarada: en la ventana, expuesto al aire y protegido. No se ha confirmado que esté fuera del hueco; no se acredita remotamente aire exterior abierto.

CO2: 19 lecturas, mínimo 365.9, máximo 444.7, media 393.31 ppm. Todas las muestras de esta captura están en 350–500 ppm. Recibidos 19 mensajes de cada variable, frente a 20 teóricos; se conserva el hueco observado. Datos y condiciones completos adjuntos.

La comparación T-8.6 sigue pendiente de los escenarios ventilado y cerrado/ocupado, y de la aceptación del uso de habitación como aproximación de aula. No se declara cerrada la issue con esta primera captura.

# Estado de la evidencia T-8.2 / #141

Captura física experimental realizada el 28/10/2026. Este paquete conserva
los originales de 60 muestras y el cálculo publicado en la issue #141.
La PR archiva evidencia; no certifica la calibración ni completa #142/#143.

Tras la captura, el responsable comunicó 4,45–4,56 V en VCC–GND del MQ-135,
frente a los 4,89 V que usó el firmware. No hubo mediciones sincronizadas de
alimentación durante la captura original. La sensibilidad adjunta es un cálculo
hipotético, NO una corrección física validada ni nuevas muestras.

Ro original 54,117312415 kOhm: CANDIDATO, no calibración vigente.
La resistencia de carga es nominal y la topología interna permanece supuesta.
No se sustituye silenciosamente el original ni se adopta el punto medio como
medición exacta. La ubicación exterior fue declarada por el responsable; luego
el equipo se trasladó al interior. No se realizó una nueva captura exterior
válida después de ese traslado en esta entrega.

Pendiente: revisar estabilidad y supuestos eléctricos, repetir/recalcular con
alimentación documentada cuando corresponda, y aceptación del resultado.
No se incluyen credenciales, config.h, .env ni datos privados del equipo.
